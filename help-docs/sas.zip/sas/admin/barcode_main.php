<table>
<tr>
<td><a href='html/index.php'>Generate Bar code</a></td>
</tr>

</table>