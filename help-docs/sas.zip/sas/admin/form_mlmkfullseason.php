<center><h1>shop allocation system</h1>
<h3>maintenance last market double</h3>
<h3>full season</h3>
<h2>Maintenance Reciept</h2>
</center>
<form>
<table>
	<tr>
	<td>reciept number:</td>
	<td>ddd</td>
	</tr>
	<tr>
	<td>Date:</td>
	<td><?php echo date('m/d/Y');?></td>
	</tr>
	<tr>
	<td>Recieved from:</td>
	<td><input type='text' size='80'></td>
	</tr>
	<tr>
	<td>sum of rupees:</td>
	<td><select name='amount'>
	<option>Twenty three thousand seven hundred and thirty only</option>
	<option>Fourteen thousand eight hundred and thirty two only</option>
	<option>Twenty nine thousand six hundred and sixty three only</option>
	<option>Eighteen thousand five hundred and thirty nine only</option>
	<option>Nine thousand two hundred and seventy only</option>
	<option>Eight thousand eight hundred and ninety nine only</option>
	<option>Five thousand five hundred and sixty two only</option>

	</select>
	</td>
	</tr>
	<tr>
	<td>cash/ cheque towards:</td>
	<td><input type='text' size='80'></td>
	</tr>
</table>
</form>