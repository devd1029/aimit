<head>
	<style>
	input[type='text'],input[type='number'],input[type='email']{
		border:none;
		border-bottom:2px solid black;
	}
	</style>
</head>


<body>
<form>
	<table>
	<h3>
		</legend><u>REFERENCE FORM DB 2014-15 BELOW:</u></legend></h3>
		<tr><td>Form No:</td><td><input type="number" name="form" /></td>
			<td><select name="received"/><option>Email Received</option><option>Email Not Received</option></select></td>
			<td><select name="paid"/><option>Paid</option><option>Not Paid</option></select></td></tr>
			<tr><td></td></tr>
			<tr><td>DNA Enabled:</td><td><select name="dnd"/><option>DND</option><option>No DND</option></select></td></tr>
			<tr><td></td></tr>
			<tr><td>Old Stall Color No:</td><td><input type="text" name="old_stall_no" /></td>
			<td><input type="number" name="old_stall" /></td></tr>
			<tr><td></td></tr>
			
			<tr><td>New Stall Color No:</td><td><input type="text" name="new_stall_no" /></td>
			<td><input type="number" name="new_stall" /></td></tr>
			<tr><td></td></tr>
			<tr><td>Full Name:</td><td><input type="text" name="name" /></td></tr>
			<tr><td></td></tr>
			<tr><td>Email Id:</td><td><input type="text" name="email" /></td></tr>
			<tr><td></td></tr>
			<tr><td>Mobile No:</td><td><input type="number" name="mobile" /></td></tr>
			<tr><td></td></tr>
			<tr><td>Landline No:</td><td><input type="number" name="landline" /></td></tr>
			<tr><td></td></tr>
			<tr><td>Nationality:</td><td><input type="text" name="nationality" /></td>
			<td>State of Origin:</td><td><input type="text" name="state" /></td></tr>
			<tr><td></td></tr>
			<tr><td>Address:</td><td><input type="text" name="address" /></td></tr>
			<tr><td></td></tr>
			<tr><td>Merchandise:</td><td><input type="text" name="merchandise" /></td></tr>
			<tr><td></td></tr>
			
	</table>
	</br>
	<table>	
			<h3></legend><u>Vendors WAC Details Below:</u></legend></h3>
			<tr><td>Serial No:</td><td><input type="number" name="serial" /></td></tr>
			<tr><td></td></tr>
			<tr><td>WAC Code:</td><td><input type="text" name="wac" /></td></tr>
			<tr><td></td></tr>
	</table>
</br>
	<table>	
			<h3></legend><u>SNM Created Vendors Email Login Details Below:</u></legend></h3>
			<tr><td>SNM Email Id:</td><td><input type="text" name="snm_email" /></td></tr>
			<tr><td></td></tr>
			<tr><td>SNM Password:</td><td><input type="text" name="snm_password" /></td></tr>
			<tr><td></td></tr>
	</table>
	<tr><td><input type='submit' value='submit'></td></tr>
	</form>
</body>