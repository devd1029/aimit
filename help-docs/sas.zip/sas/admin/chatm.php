<?php
	include"session.php";

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Your Company</title>
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta http-equiv="Content-Type"
 content="text/html; charset=iso-8859-1">
  <link href="css/style.css" rel="stylesheet" type="text/css">
  <link href="template.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="page-out">
<div class="page-in">
<div class="page">
<div class="main">
<div class="header">
<div class="header-top">
<h1><?php include"name.php";?></h1>
</div>
	<?php
		include"header_image.php";
?>
	<?php
		include"menu.php";
?>

</div>


<div class="content">
<div class="content-left">
<?php
	include"chatmain.php";
?>
</div>
<div class="content-right">
<?php
	include"main_right.php";
?>
</div>
</div>
<div class="footer">
<?php
	include"footer.php";
?>
</div>
</div>
</div>
</div>
</div>
</body>
</html>
