<?php
header('Location: BCGcode93.php');
?>