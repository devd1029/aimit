

<style type="text/css">
.style1 {
	background-color: #FFFFFF;
}
</style>

<table align="center"  border="0" cellpadding="0" cellspacing="0" style="width: 568px">
  <!-- head str -->
  <tbody>
<!-- head end -->

<!-- center str -->
<tr><td><table border="0" cellpadding="0" cellspacing="0" width="100%">
        <tbody><tr> 
          <!-- lhs str -->
          <!-- lhs end -->
          <!-- mid str -->
          <td align="center" height="" valign="top" width="580">

<table border="0" cellpadding="0" cellspacing="6" width="98%">
<tbody><tr><td height="6" class="style1"><img src="index.php_files/spacer.gif" alt="" border="0" height="6" width="1"></td></tr><tr>
                <td valign="top" width="50%" style="height: 170px" class="style1">
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="height: 618px">
                    <tbody>
                    <tr>
                      <td  style="height: 34px"><strong>4.SEATING AND SLEEPER</strong></td>
                    </tr>
                    <tr>
                      <td >
						<table style="width: 95%; height: 481px" align="center" class="style20">
							<tr>
								<td style="width: 156px; height: 26px" >
								<strong><br>
								B1&nbsp;&nbsp; <input type="checkbox"></strong></td>
							<td rowspan="9" style="width: 151px" class="style15">&nbsp;
							</td>
							<td style="width: 155px; height: 26px" >
							<strong>1&nbsp;&nbsp; <input type="checkbox"></strong></td>
							<td style="width: 159px; height: 26px" >
							<strong>2 <input type="checkbox"></strong></td>
							</tr>
							<tr>
								<td style="width: 156px; height: 40px" >
								<strong>B2 <input type="checkbox"></strong></td>
								<td style="width: 155px; height: 40px" >
								<strong>4<input type="checkbox"></strong></td>
								<td style="width: 159px; height: 40px" >
								<strong>3<input type="checkbox"></strong></td>
							</tr>
							<tr>
								<td style="width: 156px; height: 40px" >
								<strong>B3 <input type="checkbox"></strong></td>
								<td style="width: 155px; height: 40px" >
								<strong>5 <input type="checkbox"></strong></td>
								<td style="width: 159px; height: 40px" >
								<strong>6 <input type="checkbox"></strong></td>
							</tr>
							<tr>
								<td style="width: 156px; height: 31px" >
								<strong>B4 <input type="checkbox"></strong></td>
								<td style="width: 155px; height: 31px" >
								<strong>8 <input type="checkbox"></strong></td>
								<td style="width: 159px; height: 31px" >
								<strong>7 <input type="checkbox"></strong></td>
							</tr>
							<tr>
								<td style="width: 156px; "  rowspan="5">
								<strong>B5 <input type="checkbox"></strong></td>
								<td style="width: 155px; height: 40px" >
								<strong>9 <input type="checkbox"></strong></td>
								<td style="width: 159px; height: 40px" >
								<strong>10 <input type="checkbox"></strong></td>
							</tr>
							<tr>
								<td style="width: 155px; height: 40px" >
								<strong>12 <input type="checkbox"></strong></td>
								<td style="width: 159px; height: 40px" >
								<strong>11 <input type="checkbox"></strong></td>
							</tr>
							<tr>
								<td style="width: 155px; height: 40px" >
								<strong>13 <input type="checkbox"></strong></td>
								<td style="width: 159px; height: 40px" >
								<strong>14 <input type="checkbox"></strong></td>
							</tr>
							<tr>
								<td style="width: 155px; height: 40px" >
								<strong>16 <input type="checkbox"></strong></td>
								<td style="width: 159px; height: 40px" >
								<strong>15<input type="checkbox"></strong></td>
							</tr>
							<tr>
								<td style="width: 155px; height: 40px" >
								<strong>17 <input type="checkbox"></strong></td>
								<td style="width: 159px; height: 40px" >
								<strong>18 <input type="checkbox"></strong></td>
							</tr>
						</table>
						
						<div class="style22">
						
						<div class="style22">
						
						<br>
												<br>
							<strong><span class="style17">UPPER SLEEPER
												<br>
							<br>
&nbsp;
							</div>
							<table style="width: 94%; height: 246px" class="style20" align="center">
								<tr>
									<td class="style19" style="width: 123px; height: 41px">
									A1 <input type="CHECKBOX"></td>
									<td rowspan="5" class="style18" style="width: 121px">&nbsp;
									</td>
									<td class="style19" style="height: 41px">A2 <input type="CHECKBOX"></td>
									<td class="style19" style="height: 41px">A3 <input type="CHECKBOX"></td>
								</tr>
								<tr>
									<td class="style19" style="width: 123px; height: 40px;">A6 <input type="CHECKBOX"></td>
									<td class="style19" style="height: 40px">A5 <input type="CHECKBOX"></td>
									<td class="style19" style="height: 40px">A4 <input type="CHECKBOX"></td>
								</tr>
								<tr>
									<td class="style19" style="width: 123px; height: 40px;">A7 <input type="CHECKBOX"></td>
									<td class="style19" style="height: 40px">A8 <input type="CHECKBOX"></td>
									<td class="style19" style="height: 40px">A9 <input type="CHECKBOX"></td>
								</tr>
								<tr>
									<td class="style19" style="width: 123px; height: 40px;">A12 <input type="CHECKBOX"></td>
									<td class="style19" style="height: 40px">A11 <input type="CHECKBOX"></td>
									<td class="style19" style="height: 40px">A10 <input type="CHECKBOX"></td>
								</tr>
								<tr>
									<td class="style19" style="width: 123px; height: 40px;">A13 <input type="CHECKBOX"></td>
									<td class="style19" style="height: 40px">A14 <input type="CHECKBOX"></td>
									<td class="style19" style="height: 40px">A15 <input type="CHECKBOX"></td>
								</tr>
							</table>
								</span>
							</strong>
						</div>
												</td>
                    </tr>
                    
                  </tbody></table></td>
              </tr>
            </tbody></table> 

			</td>
          <!-- mid end -->
        </tr>
      </tbody></table></td></tr>
<!-- center end -->



<!-- footer str -->
<!-- footer end -->


</tbody></table>


