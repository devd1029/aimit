<?php
$hostname="localhost";
$username="root";
$password="mohin";
$database="shop";

$con = mysql_connect($hostname,$username,$password,$database) or die (mysql_error());

mysql_select_db($database,$con);
?>