<head>
	<link rel="stylesheet" type="text/css" href="chatfiles/chatstyle.css" />
</head>
<br><br>
<?php include('chatmodule.php'); ?>