<head>
	<title>STALL ENROLLMENT REQUEST FORM - (2011-2012) assistants with foreigners</title>
	<style>
	input[type='text'],input[type='number'],input[type='email']{
		border:none;
		border-bottom:2px solid black;
	}
	</style>
</head>


<body>
<form name="assistants_with_foreigners" method="post" action="insert_assistants_with_foreigners.php">
	<table>
	<center><h1>SHOP ALLOCATION SYSTEM</h1></center> </br>
	<center><h1>STALL ENROLLMENT REQUEST FORM - (2011-2012) ASSISTANTS WITH FOREIGNERS</h1></center></br>
	<h1><tr><td>Form No:</td><td><input type="number" name="no" /></td></tr>
		<tr><td>Name:</td><td><input type="text" name="name" /></td></tr>
		<tr><td>Stall info: New Color:</td><td><input type="text" name="new_color"></td>
			<td>New Number:</td><td><input type="text" name="new_number"></td></tr>
		<tr><td>Assistant's Name:</td><td><input type="text" name="assistant" /></td></tr>	
		<tr><td>Email Address:</td><td><input type="text" name="email" /></td></tr>
		<tr><td>Mobile No:</td><td><input type="number" name="mobile" /></td>
		<td>Res Phone No:</td><td><input type="number" name="phone" /></td></tr>
		<tr><td>International Mobile No:</td><td><input type="number" name="international" /></td></tr>
	 	<tr><td>Address in goa:</td><td><input type="text" name="address" /></td></tr>
		<tr><td>Merchandise/Nature of business:</td><td><input type="text" name="merchandise" /></td></tr>
		<tr><td>Nationality:</td><td><input type="text" name="nationality" /></td>
		<td>State of Origin:</td><td><input type="text" name="origin" /></td></tr>
		<tr><td>Visa type:</td><td><input type="text" name="type" /></td> 
		<td>Visa num:</td><td><input type="text" name="num" /></td></tr>
		<tr><td>Place of issue:</td><td><input type="text" name="place_of_issue" /></td> </tr>
		<tr><td>Date of issue:</td><td><input type="text" name="date_of_issue" /></td> 
		<td>Date of Expiry:</td><td><input type="text" name="date_of_expiry" /></td></tr>
		<tr><td>Date of arrival in goa/Joining of Market:</td><td><input type="text" name="date_of_arrival" /></td></tr>
		<tr><td>Stall Required for full season?: Enter Choice:</td><td><input type="text" name="fullseason" /></td><td>(Yes/No)</td></tr>
		<tr><td>If No;Last market date to be attended?:</td><td><input type="text" name="last" /></td></tr>
		<tr><td>Remarks:</td><td><input type="text" name="remarks" /></td>
		<td>Date:</td><td><input type="number" name="dat" /></td></tr></h1>
			<tr><td><input type="Submit" name="submit" value="SUBMIT"></td></tr>
	
	</table>
	</form>
</body>