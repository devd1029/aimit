<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sample calendar page by PHPJabbers.com</title>
<link href="calendar.css" rel="stylesheet" type="text/css" />
<style>
	.overlay1{
		
background-color: black;
color: white;
	}
	#close{
			position: absolute;
margin-top: -117px;
z-index:100;
visibility:hidden;
margin-left: 19%;
	}
	.overlay{
	background-color:black;
	color:white;
	position: absolute;
margin-top: -10%;
width: 24%;
	}
</style>
</head>

<body onload='b()'>
<script>
	function a(){
		document.getElementById('Events').style.visibility='hidden';
		document.getElementById('close').style.visibility='hidden';
	}
	function b(a){
		document.getElementById('overlay').style.visibility='hidden';
		if(a==1){
			document.getElementById('overlay').style.visibility='visible';
		}
		if(a==2){
		document.getElementById('overlay').style.visibility='hidden';
		}
	}
</script>
<div id="Calendar"> </div>
<div class='overlay' id='overlay' >
<?php
error_reporting(0);
include 'frame.php';
?>
</div>
<input type="button" value='create a new event' onclick='b(1)'>
<div><input type='button' value='close' id ='close' onclick='a()'> <div id="Events" class='overlay1'></div></div>
<script language="javascript" src="calendar.js"></script>



</body>
</html>