

<form method='post' action="<?php echo $_SERVER['PHP_SELF'];?>" id='form'>
Enter Event name: <input type='text' name='eventname'><br>
Enter Event Description: <input type='text' name='eventdescription'><br>
<input type='submit' value ='enter event'  >&nbsp;&nbsp;&nbsp;<input type='button' style='float:right;'value='close' onclick='b(2)'>
</form>
