
<style>
#form{

padding:3px;	
background-color: black;
color: white;
height: 14%;
border-radius: 8px;
border: 6px solid green;
}
#close11{
			


border-radius: 27px;
color:white;
background-color:red;
border:0px;
cursor:pointer;
	}
</style>
<style href='template.css'></style>
<form method='post' action="<?php echo $_SERVER['PHP_SELF'];?>" id='form'>
<table>
<tr><td>Enter Event name:  <input type='text' name='eventname' required/></td></tr>
<tr><td>Enter Event Description:  <textarea type='text' name='eventdescription' ></textarea></td></tr>
<tr><td>Enter Date:  <input type='text' name='date' value='<?php echo date('Y-m-d');?>' required/><br>
*(Year-Month-Day)
</td></tr>
<tr><td><input type='submit' value ='enter event'  ></td></tr><input type='button' style='float:right;'value='close' id='close11'onclick='b(2)'>
</table>
</form>
<?php
include"config.php";
	$event_name=$_POST['eventname'];
	$event_desc=$_POST['eventdescription'];
	$date=$_POST['date'];
	//inserts the data
	$query=mysql_query("INSERT INTO event_calendar_admin (event_date,title,description) VALUES 
	('$date','$event_name','$event_desc');");
	
	mysql_query("delete from event_calendar_admin where event_date='0000-00-00'");
	
	
?>
