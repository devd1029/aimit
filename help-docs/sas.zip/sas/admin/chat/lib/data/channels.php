<?php

// List containing the custom channels:
$channels = array();

// Sample channel list:
$channels[0] = 'Private';
$channels[1] = 'Public';

?>